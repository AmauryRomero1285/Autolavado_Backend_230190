'''
Docstring for schemas.schema_servicio
'''

from datetime import datetime
from pydantic import BaseModel

class ServicioBase(BaseModel):
    '''Clase para modelar los campos de tabla Servicios'''
    nombre: str
    descripcion: str
    costo: float
    duracion_minutos: int
    estado: bool
    fecha_registro: datetime
    fecha_actualizacion: datetime
# pylint: disable=too-few-public-methods, unnecessary-pass
class ServicioCreate(ServicioBase):
    '''Clase para crear un Servicio basado en la tabla Servicio'''
    pass
class ServicioUpdate(ServicioBase):
    '''Clase para actualizar un Servicio basado en la tabla Servicio'''
    pass
class Servicio(ServicioBase):
    '''Clase para realizar operaciones por ID en tabla Servicio'''
    Id: int
    class Config:
        '''Utilizar el orm para ejecutar las funcionalidades'''
        orm_mode =True
